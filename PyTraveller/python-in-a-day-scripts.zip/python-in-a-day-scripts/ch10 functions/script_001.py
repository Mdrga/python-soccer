# Make function called letsAdd
def letsAdd(x,y):
    # Make addition variable equal to x + y
    addition = x + y

    # Return addition variable
    return addition

# Print results to console
print letsAdd(3, 5)
