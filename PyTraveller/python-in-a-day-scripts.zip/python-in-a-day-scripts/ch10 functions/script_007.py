# convert to string
x = 23
print str(x)

# convert to float
y = float(40)/float(7)
print y

yInt = int(y)
print yInt

print round(y)
print int(round(y))
