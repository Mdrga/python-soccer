# Make function called letsAdd
def letsAdd(x,y):
    # Make addition variable equal to x + y
    addition = x + y

    # Return addition variable
    return addition

# Make function called subtraction
def subtraction(x,y):
    # Make subtract variable equal to x - y
    subtract = x - y

    # Return subtract variable
    return subtract

def moreSubtraction(x,y, z):
    # Make subtract variable equal to x - y - z
    subtract = x - y - z

    # Return subtract variable
    return subtract


def multiply(x,y):
    return x*y

def divide(x,y):
    division = float(x)/float(y)
    return division
