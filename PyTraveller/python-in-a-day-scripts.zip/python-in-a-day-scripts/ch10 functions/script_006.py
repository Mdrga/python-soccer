length = len("How epic are built-in functions, huh?")
print length
