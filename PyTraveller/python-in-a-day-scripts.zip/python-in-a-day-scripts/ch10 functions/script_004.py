# Make function called letsAdd
def letsAdd(x,y):
    # Make addition variable equal to x + y
    addition = x + y

    # Return addition variable
    return addition

# Make function called subtraction
def subtraction(x,y):
    # Make subtract variable equal to x - y
    subtract = x - y

    # Return subtract variable
    return subtract

print subtraction(10, 4)

def moreSubtraction(x,y, z):
    # Make subtract variable equal to x - y - z
    subtract = x - y - z

    # Return subtract variable
    return subtract

print moreSubtraction(40, 3, 11)
