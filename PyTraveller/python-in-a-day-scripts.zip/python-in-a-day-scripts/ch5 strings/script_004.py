date = "11/12/2013"

# Go through string and split where there is a '/'
date_manip = date.split('/')

# Separate the list
print date_manip[0]
print date_manip[1]
print date_manip[2]
