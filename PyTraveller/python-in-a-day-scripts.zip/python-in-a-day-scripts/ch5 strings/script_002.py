name = "Guido"

print name[0]

print name[4]

print name.upper()
print name.lower()
print name.capitalize()
