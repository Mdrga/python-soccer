date = "11/12/2013"

# Go through string and split where there is a '/'
date_manip = date.split('/')

# Show the outcome
print date_manip
