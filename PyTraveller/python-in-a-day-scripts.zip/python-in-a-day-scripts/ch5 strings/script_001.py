name = "Guido"

print name[0]

print name[4]
