# Define the variables
x = 10
y = 2

# Start if statement
if x == 10:
    print 'x = 10'
    
# If x does not equal 10, but equals 9 run this
elif x == 9:
    print 'x = 9'
    
# If its not equal to 10 or 9, run this
else:
    print 'x does not equal 9 or 10'

