# Run loop in range 0 - 5
# Counter changes automatically in each iteration
for counter in range(0,5):
    # Show the value of counter
    print counter
