# Start counter at 0
counter = 0

# While 'counter' is less than or equal to 5, run the loop
while counter < 5:
    # Show counter value
    print counter
    # Increase counter by 1
    counter = counter + 1
