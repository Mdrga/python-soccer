# Create list of numbers
number_list = [1,2,3,4,5]

# Loop each number in number_list
for x in number_list:
    # Print each number to the power of 2
    print x**2
