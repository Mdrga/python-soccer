# Create the list of epic programmers
epic_programmer_list = ["Tim Berners-Lee",
                        "Guido van Rossum",
                        "Linus Torvalds",
                        "Larry Page",
                        "Sergey Brin",]

# Add myself to the end of the list
epic_programmer_list.append("Me")

# Looping through each item in epic_programmer_list
for programmer in epic_programmer_list:
    # Print the programmers' name to console
    print 'An epic programmer: ' + programmer
