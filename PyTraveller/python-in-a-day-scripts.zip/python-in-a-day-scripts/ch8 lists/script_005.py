# Create the list of epic programmers
epic_programmer_list = ["Tim Berners-Lee",
                        "Guido van Rossum",
                        "Linus Torvalds",
                        "Larry Page",
                        "Sergey Brin",]

# Add myself to the end of the list
epic_programmer_list.append("Me")

# Print to console
print "An epic programmer: " + epic_programmer_list[0]
print "An epic programmer: " + epic_programmer_list[1]
print "An epic programmer: " + epic_programmer_list[2]
print "An epic programmer: " + epic_programmer_list[3]
print "An epic programmer: " + epic_programmer_list[4]

# Add this line to show myself in the console
print "An epic programmer: " + epic_programmer_list[5]
