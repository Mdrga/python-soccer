from math import sqrt, exp

print sqrt(16)
print exp(2)
