import math

print math.sqrt(16)
