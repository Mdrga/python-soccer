from math import sqrt

print sqrt(16)
