# Import our module
import smallMathsModule

# multiplyBy5 function
print smallMathsModule.multiplyBy5(3)

# add5 function
print smallMathsModule.add5(9)

# randomAdd function
print smallMathsModule.randomAdd(8)
