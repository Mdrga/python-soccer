# Make the dictionary
dictionary_name = { 'item_1' : 1, 'item_2' : 2, 'item_3' : 3 }

# Search dictionary for 'item_1' and retrieve its data
print dictionary_name['item_1']
