# Create programmer dictionary
epic_programmer_dict = {'Tim Berners-Lee' : 'tbl@gmail.com',
                        'Guido van Rossum' : 'gvr@gmail.com',
                        'Linus Torvalds': 'lt@gmail.com' }

# Changes email address
epic_programmer_dict['Tim Berners-Lee'] = 'tim@gmail.com'
# Check it changed correctly
print 'New email for Tim: ' + epic_programmer_dict['Tim Berners-Lee']
