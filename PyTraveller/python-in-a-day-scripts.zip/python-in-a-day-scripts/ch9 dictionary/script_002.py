# Create programmer dictionary
epic_programmer_dict = {'Tim Berners-Lee' : 'tbl@gmail.com',
                        'Guido van Rossum' : 'gvr@gmail.com',
                        'Linus Torvalds': 'lt@gmail.com' }

# Check dictionary is working
print epic_programmer_dict

# Check we can retrieve Tim's email from the dictionary
print epic_programmer_dict['Tim Berners-Lee']
