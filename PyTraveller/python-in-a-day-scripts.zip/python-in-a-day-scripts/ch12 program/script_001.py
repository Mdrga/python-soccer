# Our epic programmer dict from before
epic_programmer_dict = {
    'Tim Berners-Lee' : 'tbl@gmail.com',
    'Guido van Rossum' : 'gvr@gmail.com',
    'Linus Torvalds': 'lt@gmail.com',
    'Larry Page' : 'lp@gmail.com',
    'Sergey Brin' : 'sb@gmail.com',
    }
print epic_programmer_dict
