x = 10
y = 2

if x == 10:
    # in the statement
    print 'x = 10'
    # still in the statement

# Not in the statement. Statement finished
