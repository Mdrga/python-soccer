x = 10
y = 2

print(x+y)
