x = 10
y = 2

''' Prints x + y
to the shell '''
print(x+y)
