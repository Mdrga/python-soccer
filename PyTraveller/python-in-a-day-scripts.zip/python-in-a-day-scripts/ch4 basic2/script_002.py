x = 10
y = 2

# Print x + y
print(x+y)
