x = 10
y = 2

if x == 10:
    print 'x = 10'
