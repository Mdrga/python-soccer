string_array = ["Ruby", "In", "A", "Day"]
