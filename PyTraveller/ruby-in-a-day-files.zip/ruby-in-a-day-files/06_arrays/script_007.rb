string_array = ["Ruby", "In", "A", "Day"]

for item in string_array
  # prints out the string
  puts item
end
