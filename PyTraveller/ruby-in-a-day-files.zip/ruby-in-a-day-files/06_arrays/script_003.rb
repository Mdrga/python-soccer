string_array = ["Ruby", "In", "A", "Day"]

# Prints out the text at index 0
puts "Index 0:" + string_array[0]

# Prints out the text at index 3
puts "Index 3:" + string_array[3]