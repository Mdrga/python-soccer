string_array = ["Ruby", "In", "A", "Day"]

string_array.each_with_index do |item, index|
  # prints out the string
  puts "Index #{index}: #{item}"
end