string_array = ["Ruby", "In", "A", "Day"]

# Prints out the text at index 0
puts string_array[0]

# Prints out the text at index 3
puts string_array[3]