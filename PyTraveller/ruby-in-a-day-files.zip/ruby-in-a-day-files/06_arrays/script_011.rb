string_array = ["Ruby", "In", "A", "Day"]
# Make a counter
counter = 0

string_array.each do |item|
  # prints out the string
  puts "Index #{counter}: #{item}"
  # Increase counter by 1
  counter += 1
end