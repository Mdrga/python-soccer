string_array = ["Ruby", "In", "A", "Day"]

string_array.each do |item|
  # prints out the string
  print "#{item} "
end