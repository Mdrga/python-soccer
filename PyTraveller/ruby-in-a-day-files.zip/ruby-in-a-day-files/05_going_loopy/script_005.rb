# Loop goes around from 0 to 5
for my_num in 0..5
  puts my_num
end
