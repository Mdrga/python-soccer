counter = 0

loop do
  # print the counter value
  puts counter
  
  # Increase counter by 1
  counter += 1
  
  # When counter goes above 5,
  # we need to break the loop
  if counter > 5
    break
  end
end
