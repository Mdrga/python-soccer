counter = 0
while counter < 5
  puts counter
  counter = counter + 1
end
