counter = 0
while counter <= 5
  puts counter
  # Increase the counter value by 1
  counter = counter + 1
end
