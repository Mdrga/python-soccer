my_string = "Ruby In A Day"

# print capitalize my_string
print "Capitalize: "
puts my_string.capitalize

# print upcase my_string
print "Upcase: "
puts my_string.upcase

# prints downcase mystring
print "Downcase: "
puts my_string.downcase

# prints length mystring
print "Length: "
puts my_string.length