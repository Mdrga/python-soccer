my_date = "11/12/2013"

# Split where there are /'s
puts my_date.split("/")