my_date = "11/12/2013"

# Split where there are /'s
my_date_split = my_date.split("/")

# Print third part of split string
puts my_date_split[2]