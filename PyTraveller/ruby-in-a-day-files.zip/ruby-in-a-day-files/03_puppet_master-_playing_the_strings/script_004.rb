my_string = "Ruby In A Day"

# Print first character in string
puts my_string[0]

# Print fourth character in string
puts my_string[3]
