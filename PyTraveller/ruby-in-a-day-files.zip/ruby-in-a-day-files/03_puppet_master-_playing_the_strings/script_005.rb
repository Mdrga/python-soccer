my_string = "Ruby In A Day"

# Print characters 0 to 3
puts my_string[0..3]

# Print characters 6 to 8
puts my_string[6..8]
