my_string = "Ruby In A Day"

# prints the variable my_string
puts my_string