x = 10;

# If x is equal to 5
if x == 5
  # Print out this
  puts "x equals 5"
elsif x == 4
  # Print x equals 4
  puts "x equals 4"

elsif x > 8
  # Print x is greater than 8
  puts "x is greater than 8"

else
  # Print x does not equal 5
  puts "x does not equal 5"
end