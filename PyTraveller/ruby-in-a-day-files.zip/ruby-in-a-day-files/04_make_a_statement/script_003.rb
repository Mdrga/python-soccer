x = 4;

# If x is equal to 5
if x == 5
  # Print out this
  puts "x equals 5"
  
elsif x == 4
  # Print x equals 4
  puts "x equals 4"
  
else
  # Print x does not equal 5
  puts "x does not equal 5"
end