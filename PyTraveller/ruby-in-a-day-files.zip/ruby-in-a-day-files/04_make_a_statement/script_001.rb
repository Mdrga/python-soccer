x = 5;

# If x is equal to 5
if x == 5
  # Print out this
  puts "x equals 5"
end
