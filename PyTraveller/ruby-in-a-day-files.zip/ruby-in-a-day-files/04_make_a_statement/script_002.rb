x = 4;

# If x is equal to 5
if x == 5
  # Print out this
  puts "x equals 5"
else
  # Print x does not equal 5
  puts "x does not equal 5"
end
