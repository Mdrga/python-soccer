my_hash = Hash.new

puts my_hash