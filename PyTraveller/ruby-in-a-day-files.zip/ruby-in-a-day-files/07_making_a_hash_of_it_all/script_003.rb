my_hash = Hash.new

# Add key and a value
my_hash["firstname"] = "Tony"

puts my_hash