# Ask user for their firstname
print "Please input your first name: "
firstname = gets.chomp

# Ask user for their lastname
print "Please input your last name: "
lastname = gets.chomp

# Ask user for their lastname
print "Please input your nickname: "
nickname = gets.chomp


# Print out their details
puts "Your firstname is: #{firstname.capitalize}"
puts "Your lastname is: #{lastname.capitalize}"
puts "Your nickname is: #{nickname.capitalize}"