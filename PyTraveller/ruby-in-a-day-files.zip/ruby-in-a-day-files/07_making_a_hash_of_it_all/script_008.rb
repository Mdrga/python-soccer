# Ask user for their firstname
print "Please input your first name: "
firstname = gets.chomp

# Ask user for their lastname
print "Please input your last name: "
lastname = gets.chomp

# Ask user for their lastname
print "Please input your nickname: "
nickname = gets.chomp

# Make a new hash
my_lazy_hash = Hash.new

# Add details to the hash
my_lazy_hash["firstname"] = firstname.capitalize
my_lazy_hash["lastname"] = lastname.capitalize
my_lazy_hash["nickname"] = nickname.capitalize

# Print out the hash
puts my_lazy_hash
