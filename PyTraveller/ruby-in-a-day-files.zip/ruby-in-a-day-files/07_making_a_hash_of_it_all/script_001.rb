my_hash = {
  # key       => value
  "firstname" => "Tony",
  "lastname" => "Stark",
  "nickname" => "Iron Man",
}

puts my_hash["firstname"]
puts my_hash["nickname"]