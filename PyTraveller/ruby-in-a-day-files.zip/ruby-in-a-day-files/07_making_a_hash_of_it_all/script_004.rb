print "Please input some words: "

# Asks user for an input
some_variable = gets.chomp

# Print out their input
puts "You entered: #{some_variable}"