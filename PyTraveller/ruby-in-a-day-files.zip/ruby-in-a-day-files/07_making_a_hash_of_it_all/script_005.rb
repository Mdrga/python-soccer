print "Please input your name: "

# Ask user for their name
firstname = gets.chomp

# Print out their firstname
puts "Your firstname is: #{firstname}"
