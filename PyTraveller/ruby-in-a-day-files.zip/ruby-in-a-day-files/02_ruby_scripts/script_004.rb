puts "In the script"
puts "A new line"

# prints out 2 + 2
puts 2+2
