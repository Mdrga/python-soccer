puts "In the script"
puts "A new line"

=begin
prints out 2 + 2
Another line for fun
=end
puts 2+2
