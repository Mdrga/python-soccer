puts "In the script"
puts "A new line"