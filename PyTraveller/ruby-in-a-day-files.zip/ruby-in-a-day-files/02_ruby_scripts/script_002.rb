puts "In the script"
puts "A new line"
2+2