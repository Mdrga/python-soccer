puts "In the script"
puts "A new line"
puts 2+2