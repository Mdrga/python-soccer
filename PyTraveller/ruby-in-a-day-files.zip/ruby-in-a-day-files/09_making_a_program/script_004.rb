avengers_bank = Hash.new

# the person = [pin, money]
avengers_bank["iron man"] = [5432, 5000000]
avengers_bank["the hulk"] = [2486, 7823]

puts "Who's bank account do you want to access?"
name = gets.chomp.downcase

# Check that the person exists in the bank
if avengers_bank[name]
  # Get user to input the pin
  print "Found the bank account. Please enter the pin: "
  pin = gets.chomp
  
  # get the array [pin, money]
  client_details = avengers_bank[name]
  if pin == client_details[0]
    puts "We're in!"
  else
    puts "Pin does not match"
  end
  
else
  puts "Name not recognised."
  puts "Exiting..."
end
