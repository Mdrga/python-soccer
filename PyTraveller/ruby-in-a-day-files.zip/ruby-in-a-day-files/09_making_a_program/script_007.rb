#Convert 1000000 to 1,000,000
def fancy_number(num)
  # Convert it to a string
  num_string = num.to_s()
  
  # Reverse then scan(...) goes through every 3 characters
  # and then .join adds the comma
  converted = num_string.reverse.scan(/.{3}|.+/).join(",")
  
  # Return the string
  return converted.reverse
end

# check it works
puts fancy_number(1452034)

avengers_bank = Hash.new

# the person = [pin, money]
avengers_bank["iron man"] = [5432, 5000000]
avengers_bank["the hulk"] = [2486, 7823]

puts "Who's bank account do you want to access?"
name = gets.chomp.downcase

# Check that the person exists in the bank
if avengers_bank[name]
  # Get user to input the pin
  print "Found the bank account. Please enter the pin: "
  pin = gets.chomp
  
  # get the array [pin, money]
  client_details = avengers_bank[name]
  if pin == client_details[0].to_s()
    puts "Welcome back, #{name}"
    puts "Current balance: #{client_details[1]}"
  else
    puts "Pin does not match"
  end
  
else
  puts "Name not recognised."
  puts "Exiting..."
end
