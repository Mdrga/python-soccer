avengers_bank = Hash.new

# the person = [pin, money]
avengers_bank["iron man"] = [5432, 5000000]
avengers_bank["the hulk"] = [2486, 7823]
