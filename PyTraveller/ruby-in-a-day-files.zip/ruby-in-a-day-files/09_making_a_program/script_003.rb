avengers_bank = Hash.new

# the person = [pin, money]
avengers_bank["iron man"] = [5432, 5000000]
avengers_bank["the hulk"] = [2486, 7823]

puts "Who's bank account do you want to access?"
name = gets.chomp.downcase

# Check that the person exists in the bank
if avengers_bank[name]
  puts "We're in!"
else
  puts "Name not recognised."
  puts "Exiting..."
end
