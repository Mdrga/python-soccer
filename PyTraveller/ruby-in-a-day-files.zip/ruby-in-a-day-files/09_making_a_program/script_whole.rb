avengers_bank = Hash.new

                            #pin, money
avengers_bank["Iron Man"] = ["5432", 5000000]
avengers_bank["The Hulk"] = ["2486", 7823]

#Convert 1000000 to 1,000,000
def fancy_number(num)
  # Convert it to a string
  num_string = num.to_s()
  converted = num_string.reverse.scan(/.{3}|.+/).join(",")
  return converted.reverse
end


puts "Who's bank account do you want to access?"
name = gets.chomp

# See if the account exists
if avengers_bank[name]
  print "Found the bank account. Please enter the pin: "
  client_details = avengers_bank[name]
  pin = gets.chomp
  if pin == client_details[0]
    puts "Welcome back, #{name}"
    
    # Get the fancy number
    number_with_commas = fancy_number(client_details[1])
    puts "Here is your current balance: #{number_with_commas}"
    
    print "Would you like to withdraw some money? (y/n) "
    withdraw = gets.chomp
    
    if withdraw.downcase == "y"
      print "How much would you like to withdraw? "
      amount = gets.chomp
      #convert input string to integer
      money_left = client_details[1] - amount.to_i
      puts "You have #{money_left} remaining in your account."
      puts "Thank you for banking with us today."
    elsif withdraw.downcase == "n"
      puts "No problem. Thank you for banking with us."
    else
      puts "I did not understand your response."
      puts "Exiting..."
    end
  else
    puts "Pin does not match"
    puts "Exiting..."
  end
else
  puts "We have nobody by that name."
  puts "Exiting..."
end
