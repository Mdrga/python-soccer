# Modify function to accept a variable
def print_avengers(avengers)
    
  # Loop to print out avengers
  avengers.each do |single_avenger|
    puts single_avenger
  end
end

# array of avengers
avengers_array = ["Iron Man", "The Hulk",
            "Thor", "Captain America",
            "Black Widow", "Hawkeye"]

print_avengers(avengers_array)