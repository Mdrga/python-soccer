def factor_of_3(n)
  
  # Work out remainder
  remainder = n % 3
  
  if remainder == 0
    puts "Factor of three"
  else
    puts "Not a factor of three"
  end
end

factor_of_3(9)
factor_of_3(11943)