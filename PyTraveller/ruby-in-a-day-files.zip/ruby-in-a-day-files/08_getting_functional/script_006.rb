# function for printing arrays
def print_array(array)
    
  # Loop to print out array items
  array.each do |item|
    puts item
  end
end

# array of avengers
avengers_array = ["Iron Man", "The Hulk",
            "Thor", "Captain America",
            "Black Widow", "Hawkeye"]

print_array(avengers_array)
