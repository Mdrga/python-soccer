def some_function
  # Do something here
end

# Call the function
some_function