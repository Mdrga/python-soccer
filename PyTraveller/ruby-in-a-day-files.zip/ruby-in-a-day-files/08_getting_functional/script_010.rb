def factor_of_3(n)
  
  # Work out remainder
  remainder = n % 3
  
  if remainder == 0
    return true
  else
    return false
  end
end

puts factor_of_3(9)
puts factor_of_3(8)