def print_avengers
  # array of avengers
  avengers = ["Iron Man", "The Hulk",
              "Thor", "Captain America",
              "Black Widow", "Hawkeye"]
  
  # Loop to print out avengers
  avengers.each do |single_avenger|
    puts single_avenger
  end
end

# Call the function
print_avengers

# Call the function again. For fun.
# Create a blank line first
puts
puts "Second function"
print_avengers