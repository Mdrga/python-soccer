def factor_of_3(n)
  
  # Work out remainder
  remainder = n % 3
  
  if remainder == 0
    return true
  else
    return false
  end
end

factor_of_3(9)
factor_of_3(8)