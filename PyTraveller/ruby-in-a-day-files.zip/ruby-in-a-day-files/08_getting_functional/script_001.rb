def some_function
  # Do something here
end
